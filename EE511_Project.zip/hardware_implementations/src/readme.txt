version 0
- uses only off-chip memory
- no optimizations
- no parallel
- no packing
- use float
