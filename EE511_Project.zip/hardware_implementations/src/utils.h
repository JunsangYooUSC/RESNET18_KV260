/******************************************************************************
 * Filename: utils.h
 * Author: Junsang Yoo
 *
 * Description:
 * util functions
 *
 * Functions:
 * - 
 ******************************************************************************/

#ifndef UTILS_H
#define UTILS_H

#endif
