version 1
- uses only off-chip memory
- minimum pragmas applied
- no parallel
- no packing
- use float
