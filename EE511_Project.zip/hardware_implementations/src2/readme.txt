version 2
- uses on-chip memory for activations
- pragmas applied
- no parallel
- packing
- use 8bit fixed
